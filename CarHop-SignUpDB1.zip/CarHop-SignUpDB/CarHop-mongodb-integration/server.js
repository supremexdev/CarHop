import express from 'express';
import cors from 'cors';
import { MongoClient } from 'mongodb';
import dotenv from 'dotenv';
import bcrypt from "bcryptjs";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const uri = process.env.MONGODB_URI;

// Check if URI exists
if (!uri) {
  console.error('ERROR: MONGODB_URI is not defined in .env file');
  console.error('Please check your .env file exists and contains MONGODB_URI');
  process.exit(1);
}

console.log('Connecting to MongoDB...');
const client = new MongoClient(uri);

// Connect to MongoDB
try {
  await client.connect();
  console.log(' Connected to MongoDB!');
} catch (error) {
  console.error(' Failed to connect to MongoDB:', error.message);
  process.exit(1);
}

const db = client.db("carhop");

// API Routes
app.get('/api/renters', async (req, res) => {
  try {
    const renters = await db.collection("renters").find({}).toArray();
    res.json(renters);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/tenants', async (req, res) => {
  try {
    const tenants = await db.collection("tenants").find({}).toArray();
    res.json(tenants);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/vehicles', async (req, res) => {
  try {
    const vehicles = await db.collection("Vehicles").find({}).toArray();
    res.json(vehicles);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

/**
 * Authentication 
 */
//grab user type renter/tenant
function getUserType(userType) {
  if (userType === "users") return "tenants";
  if (userType === "renters") return "renters";
  return null;
}
//
//For Creation of Account
//express receives request "/api/auth/signup" from DB run:
app.post("/api/auth/signup", async (req, res) => {
  try {
    const { userType, name, email, password } = req.body;

    //if there is no collection with name of (userType) error
    const collectionName = getUserType(userType);
    if (!collectionName) return res.status(400).json({ message: "Invalid userType." });
    //else if not all fields are filled, error
    if (!name || !email || !password) {
      return res.status(400).json({ message: "Missing required fields." });
    }
    //remove excess whitespace from eamil, make lowercase
    const correctedEmail = String(email).trim().toLowerCase();

    // Check if email already exists to prevent duplicates
    const existing = await db.collection(collectionName).findOne({ email: correctedEmail });
    if (existing) {
      return res.status(409).json({ message: "Email already in use." });
    }
    // use bcrypt to create a password hashcode
    const passwordHash = await bcrypt.hash(String(password), 10);

    //MongoDB object creation
    //
    //create user object for integration in the MongoDB
    const doc = {
      name: String(name).trim(),
      email: correctedEmail,
      passwordHash,
      createdAt: new Date(),
    };
    //insert object into the MongoDB
    const result = await db.collection(collectionName).insertOne(doc);
    //return inserted object
    return res.status(201).json({
      id: result.insertedId,
      name: doc.name,
      email: doc.email,
      userType,
    });
  } catch (err) {
    // Catch errors for duplicate emails and server error
    if (err?.code === 11000) {
      return res.status(409).json({ message: "Email already in use." });
    }
    console.error(err);
    return res.status(500).json({ message: "Server error." });
  }
});

//
//For logging into Account
//receive request from post
app.post("/api/auth/login", async (req, res) => {
  try {
    const { userType, email, password } = req.body;
    //get user ttype, if not valid error
    const collectionName = getUserType(userType);
    if (!collectionName) return res.status(400).json({ message: "Invalid userType." });
    //if no email or password error
    if (!email || !password) {
      return res.status(400).json({ message: "Email and password are required." });
    }
    //remove extra whitespace/case
    const correctedEmail = String(email).trim().toLowerCase();

    // Find user by email within the MongoDB
    const user = await db.collection(collectionName).findOne({ email: correctedEmail });
    if (!user) {
      return res.status(401).json({ message: "Invalid credentials." });
    }

    // Verify password using bcrypt
    const verified = await bcrypt.compare(String(password), user.passwordHash || "");
    if (!verified) {
      return res.status(401).json({ message: "Invalid credentials." });
    }

    // return user object, minus password
    return res.json({
      id: user._id,
      name: user.name,
      email: user.email,
      userType,
    });
    //catch errors
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Server error." });
  }
});

/**
 * 
 * 
 */
const PORT = 3001;
app.listen(PORT, () => {
  console.log(` Server running on http://localhost:${PORT}`);
});