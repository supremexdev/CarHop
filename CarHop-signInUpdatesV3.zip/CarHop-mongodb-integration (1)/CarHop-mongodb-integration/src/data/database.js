
/**
 * Auth
 */
//base api grab
const API_BASE = import.meta?.env?.VITE_API_BASE || "http://localhost:3001";
//
async function handleJson(res) {
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data?.message || "Request failed");
  return data;
}

//create function to use when signing user up
//call to pass from the frontend to the backend
export async function signup({ userType, firstName, lastName, email, password, insuranceProvider, insuranceNumber, age, licenseNumber }) {
  const res = await fetch(`${API_BASE}/api/auth/signup`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userType, firstName, lastName, email, password, insuranceProvider, insuranceNumber, age, licenseNumber, }),
  });
  return handleJson(res);
}

//create function to check db with
export async function login({ userType, email, password }) {
  const res = await fetch(`${API_BASE}/api/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userType, email, password }),
  });
  return handleJson(res);
}
/**
 */

export async function getRenters() {
  try {
    const response = await fetch(`${API_BASE}/api/renters`);
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error fetching renters:", error);
    return [];
  }
}
 

export async function getVehicles() {
  try {
    const response = await fetch(`${API_BASE}/api/vehicles`);
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error fetching vehicles:", error);
    return [];
  }
}

export async function getTenants() {
  try {
    const response = await fetch(`${API_BASE}/api/tenants`);
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error fetching tenants:", error);
    return [];
  }
}