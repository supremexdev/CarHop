import { useState } from 'react';
import { X, Mail, Lock, User, Car, Users } from 'lucide-react';
import { signup, login } from "../data/database";


interface SignInModalProps {
  onClose: () => void;
  onSignIn: (email: string) => void;
}

export function SignInModal({ onClose, onSignIn }: SignInModalProps) {
  const [isSignUp, setIsSignUp] = useState(false);
  const [userType, setUserType] = useState<'users' | 'renters'>('users');
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    insuranceProvider: '',
    insuranceNumber: '',
    age: '',
    licenseNumber: '',
  });

  /**
   * auth
   */
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  //handlesubmit to pass information from the submit form to the backend
  const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();
  setError("");
  setLoading(true);

  //when submit is clicked , try one of the following
  try {
    //if isSignUp == true, we are signing up, we  will create a new account using the form data
    if (isSignUp) {
      await signup({
        userType,
        firstName: formData.firstName,
        lastName: formData.lastName,
        email: formData.email,
        password: formData.password,
        insuranceProvider: formData.insuranceProvider,
        insuranceNumber: formData.insuranceNumber,
        age: formData.age,
        licenseNumber: formData.licenseNumber,
      });
      //switch menu after signup to sign into the profile
      setError("");
      setIsSignUp(false);
    } else {
      //else we are signing in, find account in MongoDB with user credentials
      const user = await login({
        userType,
        email: formData.email,
        password: formData.password,
      });
      //pass user email to props
      onSignIn(user.email);
      onClose();
    }
    //error handling
  } catch (err: any) {
    setError(err?.message || "Something went wrong");
  } finally {
    setLoading(false);
  }
  };
  /**end auth
   */

  return (
    <div className="fixed inset-0 bg-secondary bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full">
        <div className="p-6 border-b border-gray-200 flex items-center justify-between">
          <h2 className="text-gray-900 font-bold text-xl">{isSignUp ? 'Create Account' : 'Sign In'}</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="w-6 h-6 text-gray-600" />
          </button>
        </div>

        {/* User Type Tabs */}
        <div className="px-6 pt-6 pb-4">
          <div className="flex gap-2 bg-gray-100 rounded-lg p-1">
            <button
              type="button"
              onClick={() => {
                setUserType('users');
                setError("");
               }}
              className={`flex-1 py-3 px-4 rounded-md transition-all font-medium flex items-center justify-center gap-2 ${
                userType === 'users'
                  ? 'bg-secondary text-white shadow-md'
                  : 'text-gray-600 hover:bg-gray-200'
              }`}
            >
              <Users className="w-4 h-4" />
              Users
            </button>
            <button
              type="button"
              onClick={() => {
                setUserType('renters');
                setError("");
               }}
              className={`flex-1 py-3 px-4 rounded-md transition-all font-medium flex items-center justify-center gap-2 ${
                userType === 'renters'
                  ? 'bg-secondary text-white shadow-md'
                  : 'text-gray-600 hover:bg-gray-200'
              }`}
            >
              <Car className="w-4 h-4" />
              Renters
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="px-6 pb-6">
          {error && (
            <div className="mb-4 flex items-start gap-3 rounded-lg border border-red-200 bg-red-50 p-4 text-red-800">
              <svg
                className="h-5 w-5 mt-0.5 text-red-500"
                fill="none"
                stroke="currentColor"
                strokeWidth={2}
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M12 9v3m0 4h.01M5.455 19h13.09c1.054 0 1.708-1.14 1.17-2.05L13.715 4.95c-.527-.91-1.903-.91-2.43 0L4.285 16.95c-.538.91.116 2.05 1.17 2.05z"
                />
              </svg>

              <p className="text-sm font-medium">{error}</p>
            </div>
          )}

          {isSignUp && (
            <div className="mb-4">
              <label className="block mb-2 text-gray-900 font-medium">
                <User className="inline-block w-4 h-4 mr-1" />
                First Name
              </label>
              <input
                type="text"
                required
                value={formData.firstName}
                onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 bg-white text-gray-900 placeholder-gray-400 rounded-lg focus:ring-2 focus:ring-secondary focus:border-transparent outline-none"
                placeholder="John"
              />
              <label className="block mb-2 text-gray-900 font-medium">
                <User className="inline-block w-4 h-4 mr-1" />
                Last Name
              </label>
              <input
                type="text"
                required
                value={formData.lastName}
                onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 bg-white text-gray-900 placeholder-gray-400 rounded-lg focus:ring-2 focus:ring-secondary focus:border-transparent outline-none"
                placeholder="Doe"
              />
              <label className="block mb-2 text-gray-900 font-medium">
                <User className="inline-block w-4 h-4 mr-1" />
                Insurance Provider
              </label>
              <input
                type="text"
                required
                value={formData.insuranceProvider}
                onChange={(e) => setFormData({ ...formData, insuranceProvider: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 bg-white text-gray-900 placeholder-gray-400 rounded-lg focus:ring-2 focus:ring-secondary focus:border-transparent outline-none"
                placeholder="Progressive"
              />
              <label className="block mb-2 text-gray-900 font-medium">
                <User className="inline-block w-4 h-4 mr-1" />
                Insurance Number
              </label>
              <input
                type="text"
                required
                value={formData.insuranceNumber}
                onChange={(e) => setFormData({ ...formData, insuranceNumber: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 bg-white text-gray-900 placeholder-gray-400 rounded-lg focus:ring-2 focus:ring-secondary focus:border-transparent outline-none"
                placeholder="XXX-XXXX-XXXX"
              />
              <label className="block mb-2 text-gray-900 font-medium">
                <User className="inline-block w-4 h-4 mr-1" />
                Age
              </label>
              <input
                type="text"
                required
                value={formData.age}
                onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 bg-white text-gray-900 placeholder-gray-400 rounded-lg focus:ring-2 focus:ring-secondary focus:border-transparent outline-none"
                placeholder="25"
              />
              <label className="block mb-2 text-gray-900 font-medium">
                <User className="inline-block w-4 h-4 mr-1" />
                License Number
              </label>
              <input
                type="text"
                required
                value={formData.licenseNumber}
                onChange={(e) => setFormData({ ...formData, licenseNumber: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 bg-white text-gray-900 placeholder-gray-400 rounded-lg focus:ring-2 focus:ring-secondary focus:border-transparent outline-none"
                placeholder="M800000224322"
              />
            </div>
          )}

          <div className="mb-4">
            <label className="block mb-2 text-gray-900 font-medium">
              <Mail className="inline-block w-4 h-4 mr-1" />
              Email
            </label>
            <input
              type="email"
              required
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="w-full px-4 py-3 border border-gray-300 bg-white text-gray-900 placeholder-gray-400 rounded-lg focus:ring-2 focus:ring-secondary focus:border-transparent outline-none"
              placeholder="john@example.com"
            />
          </div>

          <div className="mb-6">
            <label className="block mb-2 text-gray-900 font-medium">
              <Lock className="inline-block w-4 h-4 mr-1" />
              Password
            </label>
            <input
              type="password"
              required
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              className="w-full px-4 py-3 border border-gray-300 bg-white text-gray-900 placeholder-gray-400 rounded-lg focus:ring-2 focus:ring-secondary focus:border-transparent outline-none"
              placeholder="••••••••"
            />
          </div>

          <button
            type="submit"
            className="w-full px-6 py-3 bg-secondary text-white rounded-lg hover:bg-secondary/90 transition-colors font-medium shadow-lg"
          >
            {isSignUp ? `Create ${userType === 'users' ? 'User' : 'Renter'} Account` : 'Sign In'}
          </button>

          <div className="mt-4 text-center">
            <button
              type="button"
              onClick={() => {
                setIsSignUp(!isSignUp);
                setError("");
               }}
              className="text-secondary hover:underline"
            >
              {isSignUp ? 'Already have an account? Sign in' : "Don't have an account? Sign up"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}