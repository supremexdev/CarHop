
  # Car Rental Web App

  This is a code bundle for Car Rental Web App. The original project is available at https://www.figma.com/design/umETEyUCe1kPYem2Dy5WS5/Car-Rental-Web-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  